﻿namespace databastestLocal
{


    partial class Database1DataSet
    {
    }
}
