﻿namespace databastestLocal
{


    partial class EmpoleesDataSet
    {
    }
}

namespace databastestLocal.EmpoleesDataSetTableAdapters {
    
    
    public partial class employeeUsersTableAdapter {
    }
}
